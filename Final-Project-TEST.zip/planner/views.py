from datetime import datetime, date
from django.views import generic
from django.utils.safestring import mark_safe

from .utils import Calendar

from django.shortcuts import render
from .forms import AddressForm, UserForm
from tournamentFinder import runFinder
from .models import Tournament, User, Event
import csv


  
# view for home page
def welcomeUser(request):
    # sends form to html
    form = AddressForm(request.POST or None)
    if form.is_valid():
      form.save()
    
    context = {'form' : form}

    return render(request, "welcomeUser.html", context)

# view for tournament page
def tournamentView(request):
    # calls tournament finder method
    # visits amateurgolf.com and creates csv
    runFinder()
    
    # open created csv
    with open("tournaments.csv") as file:
      # read each row from csv file
      reader = csv.reader(file)
      for row in reader:
            # creates model object with data
            _, created = Tournament.objects.get_or_create(
                name=row[0],
                course=row[1],
                city=row[2],
                state=row[3],
                day=row[4],
                month=row[5],
                year=row[6],
                )

    # gathers all tournament objects
    tournaments = Tournament.objects.all()

    # sends to tournamentView html
    context = {'tournaments' : tournaments}

    return render(request, "tournamentView.html", context)
    
# view for creating users
def addUserView(request):
 
  # creates form for user
  formUser = UserForm(request.POST or None)
  if formUser.is_valid():
    formUser.save()

  # gets all user objects
  user = User.objects.all()

  # sends user form and users to addUserView html
  context = {"formUser" : formUser,  "users" : user}
    
  return render(request, "addUserView.html", context)

class CalendarView(generic.ListView):
    model = Event
    template_name = 'cal/calendar.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # use today's date for the calendar
        d = get_date(self.request.GET.get('day', None))

        # Instantiate our calendar class with today's year and date
        cal = Calendar(d.year, d.month)

        # Call the formatmonth method, which returns our calendar as a table
        html_cal = cal.formatmonth(withyear=True)
        context['calendar'] = mark_safe(html_cal)
        return context

def get_date(req_day):
    if req_day:
        year, month = (int(x) for x in req_day.split('-'))
        return date(year, month, day=1)
    return datetime.today()