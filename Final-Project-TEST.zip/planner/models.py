from django.db import models
from datetime import datetime, date

# Address model
class Address(models.Model):
  street = models.CharField(max_length=200)
  city = models.CharField(max_length=200)
  state = models.CharField(max_length=100)
  zipCode = models.CharField(max_length=20)

  # string return for address
  def __str__(self):
        return "{}\n{}, {}\n{}".format(self.street, self.city, self.state,self.zipCode)

# user model
class User(models.Model):
  user = models.CharField(max_length=200)
  address = models.ForeignKey(Address, on_delete=models.CASCADE)

# tournament model
class Tournament(models.Model):
  city = models.CharField(max_length=200)
  state = models.CharField(max_length=2)
  name = models.CharField(max_length=200)
  day = models.CharField(max_length=200)
  month = models.CharField(max_length=200)
  year = models.CharField(max_length=200)
  course = models.CharField(max_length=200)

  # string return for address
  def __str__(self):
        return "{}".format(self.name)

# event model
class Event(models.Model):
    title = models.OneToOneField(Tournament, on_delete=models.CASCADE)
    description = models.TextField(default='')
    start_time = models.DateTimeField(default=datetime.now, blank=True)
    end_time = models.DateTimeField(default=datetime.now, blank=True)

