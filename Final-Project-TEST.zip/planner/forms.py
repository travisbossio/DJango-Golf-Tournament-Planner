from django import forms
   
# import GeeksModel from models.py
from .models import Address, User
   
# AddressForm
class AddressForm(forms.ModelForm):
    # uses address model
    class Meta:
        model = Address
        fields = "__all__"
        
# UserForm
class UserForm(forms.ModelForm):
    # uses user model
    class Meta:
        model = User
        fields = "__all__"