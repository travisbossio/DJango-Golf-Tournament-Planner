from django.urls import path
from planner import views

# links correct urls
urlpatterns = [
    path('', views.welcomeUser, name='planner'),
    path('tournamentView/', views.tournamentView, name='create'),
    path('addUserView/', views.addUserView, name='user'),
    path('calendarView/', views.CalendarView.as_view(), name='calendar'),
]
