import requests
import bs4
import re
import csv

class TourneyInfo:

  def __init__(self, name, course, city, state, day, month, year):
    self.name = name
    self.course = course
    self.city = city
    self.state = state
    self.day = 1
    self.month = 1
    self.year = 2021

def runFinder():
  res = requests.get('https://www.amateurgolf.com/Tournaments/ByState/COLORADO')

  res.raise_for_status()

  tournamentSoup = bs4.BeautifulSoup(res.text,features="html.parser")

  blockTournament = tournamentSoup.select('ul[class="contentList"]')

  tournamentListHTML = []
  tourneyListTxt = []
  withoutNameList = []
  withoutCourseList = []
  withoutLocationList = []

  nameList = []
  courseList = []
  cityList = []
  stateList = []

  objList = []

  for i in blockTournament:
    tourney = i.select('div')
    tournamentListHTML.append(tourney)


  for futureTournament in tournamentListHTML[0]:
    name = futureTournament.select('a')
    for i in name:
      nameList.append(i.getText())
    tourneyListTxt.append(futureTournament.getText())

  del tourneyListTxt[0]

  for i,n in zip(tourneyListTxt, nameList):
    i = i.replace(n, "")
    withoutNameList.append(i)


  criteriaName = re.compile(r'([A-Z][a-z]*\s)*[A-Z]?[a-z]*')

  for i in withoutNameList:
    course = criteriaName.search(i)
    courseList.append(course.group())

  for i,n in zip(withoutNameList, courseList):
    i = i.replace(n, "")
    withoutCourseList.append(i)

  criteriaLocation = re.compile(r'([A-Za-z\s]*), ([A-Z]{2})')

  for i in (withoutCourseList):
    location = criteriaLocation.search(i)
    withoutLocationList.append(i.replace(location.group(), ''))
    cityList.append(location.group(1))
    stateList.append(location.group(2))


  for i,n,k,r in zip(nameList, courseList, cityList, stateList):
    newTournament = TourneyInfo(i,n,k,r,1,1,2021)
    objList.append(newTournament)

  rows = []

  for i in objList:
    rows.append([i.name,i.course,i.city,i.state,i.day,i.month,i.year])

  with open("tournaments.csv", 'w') as csvfile: 
      # creating a csv writer object 
      csvwriter = csv.writer(csvfile) 
          
      # writing the data rows 
      csvwriter.writerows(rows)
    